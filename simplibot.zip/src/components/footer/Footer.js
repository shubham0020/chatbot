import React from 'react';
import { NavLink } from "react-router-dom";
import { Swiper, SwipperSlider } from 'swiper/react';

import 'swiper/swiper-bundle.css';

 const Footer = () => {
  return (
    <div>

                {/* <!-- End Header -->

  <!-- ======= Hero Section ======= --> */}
  
  {/* <!-- End Hero --> */}

  <main id="main" className="pt-0">


{/*<!-- ======= About Us Section ======= --> */}

{/* <!-- End About Us Section -->



<!-- ======= Services Section ======= --> */}







{/* <!-- End Contact Section --> */}

</main>
{/* <!-- End /main -->

<!-- ======= Footer ======= --> */}
<footer id="footer">
<div className="container">
  <div className="row d-flex align-items-center">
    <div className="col-lg-6 text-lg-left text-center">
      <div className="copyright">
        &copy; Copyright <strong>ChatBot</strong>. All Rights Reserved
      </div>
      <div className="credits">
        
        Designed by <a href={'https://randomtechie.com/'}>RandomTechie</a>
      </div>
    </div>
    <div className="col-lg-6">
      <nav className="footer-links text-lg-right text-center pt-2 pt-lg-0">
        <NavLink to={'/'} className="scrollto">Home</NavLink>
        <NavLink to={'/about'} className="scrollto">About</NavLink>
        <NavLink to={'/'}>Privacy Policy</NavLink>
        <NavLink to={'/'}>Terms of Use</NavLink>
      </nav>
    </div>
  </div>
</div>
</footer>
{/* <NavLink to={'#'} className="back-to-top d-flex align-items-center justify-content-center"><i className="bi bi-arrow-up-short"></i></NavLink> */}

 
 
 
    </div>
  )
}
export default Footer;
